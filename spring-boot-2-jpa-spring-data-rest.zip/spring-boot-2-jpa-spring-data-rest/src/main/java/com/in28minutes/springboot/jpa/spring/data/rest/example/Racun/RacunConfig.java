package com.in28minutes.springboot.jpa.spring.data.rest.example.Racun;

import com.in28minutes.springboot.jpa.spring.data.rest.example.Prihod.PrihodConfig;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RacunConfig {

    public RacunConfig(){


    }
}

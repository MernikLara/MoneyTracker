package com.in28minutes.springboot.jpa.spring.data.rest.example.Kategorija;

import org.springframework.context.annotation.Configuration;

@Configuration
public class KategorijaConfig {

    public KategorijaConfig(){


    }
}

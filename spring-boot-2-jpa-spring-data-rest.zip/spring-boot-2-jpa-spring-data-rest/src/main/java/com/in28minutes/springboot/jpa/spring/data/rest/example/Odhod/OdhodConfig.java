package com.in28minutes.springboot.jpa.spring.data.rest.example.Odhod;

import org.springframework.context.annotation.Configuration;

@Configuration
public class OdhodConfig {

    public OdhodConfig(){

    }
}

package com.in28minutes.springboot.jpa.spring.data.rest.example.User;

import org.springframework.context.annotation.Configuration;

@Configuration
public class UserConfig {
    public UserConfig(){


    }

}

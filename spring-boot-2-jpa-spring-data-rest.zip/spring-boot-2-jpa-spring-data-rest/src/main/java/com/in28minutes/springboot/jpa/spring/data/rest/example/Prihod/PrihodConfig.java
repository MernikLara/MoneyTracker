package com.in28minutes.springboot.jpa.spring.data.rest.example.Prihod;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;


@Configuration
public class PrihodConfig {

  public PrihodConfig(){

  }

}
